-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: ssh_guardian_v3_1
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_migration_log`
--

DROP TABLE IF EXISTS `_migration_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_migration_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `migration_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_table` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_table` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `records_migrated` int DEFAULT '0',
  `records_skipped` int DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_migration_log`
--

LOCK TABLES `_migration_log` WRITE;
/*!40000 ALTER TABLE `_migration_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `_migration_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_heartbeats`
--

DROP TABLE IF EXISTS `agent_heartbeats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_heartbeats` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `agent_id` int NOT NULL,
  `heartbeat_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `cpu_usage` decimal(5,2) DEFAULT NULL,
  `memory_usage` decimal(5,2) DEFAULT NULL,
  `disk_usage` decimal(5,2) DEFAULT NULL,
  `load_average` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uptime_seconds` bigint DEFAULT NULL,
  `network_stats` json DEFAULT NULL,
  `process_count` int DEFAULT NULL,
  `agent_version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_agent` (`agent_id`),
  KEY `idx_timestamp` (`heartbeat_timestamp`),
  CONSTRAINT `agent_heartbeats_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_heartbeats`
--

LOCK TABLES `agent_heartbeats` WRITE;
/*!40000 ALTER TABLE `agent_heartbeats` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_heartbeats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_log_batches`
--

DROP TABLE IF EXISTS `agent_log_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_log_batches` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `batch_uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agent_id` int NOT NULL,
  `log_source` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'auth.log',
  `events_count` int DEFAULT '0',
  `events_processed` int DEFAULT '0',
  `events_failed` int DEFAULT '0',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'received',
  `processing_started_at` timestamp NULL DEFAULT NULL,
  `processing_completed_at` timestamp NULL DEFAULT NULL,
  `processing_duration_ms` int DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `batch_uuid` (`batch_uuid`),
  KEY `idx_agent` (`agent_id`),
  KEY `idx_uuid` (`batch_uuid`),
  KEY `idx_status` (`status`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `agent_log_batches_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_log_batches`
--

LOCK TABLES `agent_log_batches` WRITE;
/*!40000 ALTER TABLE `agent_log_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_log_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_ufw_commands`
--

DROP TABLE IF EXISTS `agent_ufw_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_ufw_commands` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_id` int NOT NULL,
  `command_uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `command_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` json DEFAULT NULL,
  `ufw_command` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `result_message` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `sent_at` timestamp NULL DEFAULT NULL,
  `executed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `command_uuid` (`command_uuid`),
  KEY `idx_agent` (`agent_id`),
  KEY `idx_uuid` (`command_uuid`),
  KEY `idx_status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `agent_ufw_commands_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `agent_ufw_commands_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_ufw_commands`
--

LOCK TABLES `agent_ufw_commands` WRITE;
/*!40000 ALTER TABLE `agent_ufw_commands` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_ufw_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_ufw_rules`
--

DROP TABLE IF EXISTS `agent_ufw_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_ufw_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_id` int NOT NULL,
  `rule_index` int NOT NULL,
  `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'in',
  `protocol` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Anywhere',
  `from_port` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Anywhere',
  `to_port` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interface` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_v6` tinyint(1) DEFAULT '0',
  `raw_rule` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_agent` (`agent_id`),
  KEY `idx_action` (`action`),
  CONSTRAINT `agent_ufw_rules_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_ufw_rules`
--

LOCK TABLES `agent_ufw_rules` WRITE;
/*!40000 ALTER TABLE `agent_ufw_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_ufw_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_ufw_state`
--

DROP TABLE IF EXISTS `agent_ufw_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_ufw_state` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_id` int NOT NULL,
  `is_enabled` tinyint(1) DEFAULT '0',
  `ufw_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'inactive',
  `default_incoming` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'deny',
  `default_outgoing` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'allow',
  `default_routed` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'disabled',
  `logging_level` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'low',
  `ipv6_enabled` tinyint(1) DEFAULT '1',
  `rules_count` int DEFAULT '0',
  `ufw_version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_sync` timestamp NULL DEFAULT NULL,
  `raw_status` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `agent_id` (`agent_id`),
  CONSTRAINT `agent_ufw_state_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_ufw_state`
--

LOCK TABLES `agent_ufw_state` WRITE;
/*!40000 ALTER TABLE `agent_ufw_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_ufw_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agents`
--

DROP TABLE IF EXISTS `agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agent_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hostname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agent_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'secondary',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address_internal` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mac_address` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `environment` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'production',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `health_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'unknown',
  `last_heartbeat` timestamp NULL DEFAULT NULL,
  `heartbeat_interval_sec` int DEFAULT '30',
  `version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supported_features` json DEFAULT NULL,
  `total_events_sent` bigint DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `is_approved` tinyint(1) DEFAULT '0',
  `approved_by_user_id` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `agent_uuid` (`agent_uuid`),
  UNIQUE KEY `agent_id` (`agent_id`),
  KEY `idx_uuid` (`agent_uuid`),
  KEY `idx_agent_id` (`agent_id`),
  KEY `idx_status` (`status`),
  KEY `idx_health` (`health_status`),
  KEY `approved_by_user_id` (`approved_by_user_id`),
  CONSTRAINT `agents_ibfk_1` FOREIGN KEY (`approved_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agents`
--

LOCK TABLES `agents` WRITE;
/*!40000 ALTER TABLE `agents` DISABLE KEYS */;
/*!40000 ALTER TABLE `agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_entity` (`entity_type`,`entity_id`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_events`
--

DROP TABLE IF EXISTS `auth_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL,
  `source_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'agent',
  `agent_id` int DEFAULT NULL,
  `agent_batch_id` int DEFAULT NULL,
  `simulation_run_id` int DEFAULT NULL,
  `event_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auth_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_ip` varbinary(16) DEFAULT NULL,
  `source_ip_text` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_port` int DEFAULT NULL,
  `target_server` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_port` int DEFAULT '22',
  `target_username` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failure_reason` text COLLATE utf8mb4_unicode_ci,
  `geo_id` int DEFAULT NULL,
  `block_id` int DEFAULT NULL,
  `raw_log_line` text COLLATE utf8mb4_unicode_ci,
  `processing_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `processed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ml_risk_score` tinyint unsigned DEFAULT NULL,
  `ml_threat_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ml_confidence` decimal(5,4) DEFAULT NULL,
  `is_anomaly` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_uuid` (`event_uuid`),
  KEY `idx_uuid` (`event_uuid`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_agent` (`agent_id`),
  KEY `idx_type` (`event_type`),
  KEY `idx_source_ip` (`source_ip_text`),
  KEY `idx_username` (`target_username`),
  KEY `idx_simulation` (`simulation_run_id`),
  KEY `geo_id` (`geo_id`),
  KEY `idx_auth_batch` (`agent_batch_id`),
  CONSTRAINT `auth_events_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `auth_events_ibfk_2` FOREIGN KEY (`geo_id`) REFERENCES `ip_geolocation` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_events`
--

LOCK TABLES `auth_events` WRITE;
/*!40000 ALTER TABLE `auth_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_events_daily`
--

DROP TABLE IF EXISTS `auth_events_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_events_daily` (
  `id` int NOT NULL AUTO_INCREMENT,
  `summary_date` date NOT NULL,
  `agent_id` int DEFAULT NULL,
  `total_events` int DEFAULT '0',
  `failed_events` int DEFAULT '0',
  `successful_events` int DEFAULT '0',
  `invalid_user_events` int DEFAULT '0',
  `unique_ips` int DEFAULT '0',
  `unique_usernames` int DEFAULT '0',
  `unique_countries` int DEFAULT '0',
  `ips_blocked` int DEFAULT '0',
  `top_ips` json DEFAULT NULL,
  `top_usernames` json DEFAULT NULL,
  `top_countries` json DEFAULT NULL,
  `hourly_distribution` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_date_agent` (`summary_date`,`agent_id`),
  KEY `idx_date` (`summary_date`),
  KEY `idx_agent` (`agent_id`),
  CONSTRAINT `auth_events_daily_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_events_daily`
--

LOCK TABLES `auth_events_daily` WRITE;
/*!40000 ALTER TABLE `auth_events_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_events_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_events_daily_summary`
--

DROP TABLE IF EXISTS `auth_events_daily_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_events_daily_summary` (
  `summary_date` date NOT NULL,
  `total_events` int unsigned DEFAULT '0',
  `failed_count` int unsigned DEFAULT '0',
  `successful_count` int unsigned DEFAULT '0',
  `invalid_count` int unsigned DEFAULT '0',
  `anomaly_count` int unsigned DEFAULT '0',
  `avg_risk_score` decimal(5,2) DEFAULT '0.00',
  `unique_ips` int unsigned DEFAULT '0',
  `unique_usernames` int unsigned DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`summary_date`),
  KEY `idx_summary_date` (`summary_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_events_daily_summary`
--

LOCK TABLES `auth_events_daily_summary` WRITE;
/*!40000 ALTER TABLE `auth_events_daily_summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_events_daily_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_events_ml`
--

DROP TABLE IF EXISTS `auth_events_ml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_events_ml` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_id` bigint NOT NULL,
  `model_id` int DEFAULT NULL,
  `risk_score` decimal(5,4) DEFAULT '0.0000',
  `threat_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confidence` decimal(5,4) DEFAULT '0.0000',
  `is_anomaly` tinyint(1) DEFAULT '0',
  `features_snapshot` json DEFAULT NULL,
  `inference_time_ms` int DEFAULT NULL,
  `manual_feedback` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feedback_at` timestamp NULL DEFAULT NULL,
  `feedback_by_user_id` int DEFAULT NULL,
  `feedback_notes` text COLLATE utf8mb4_unicode_ci,
  `was_blocked` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_event` (`event_id`),
  KEY `idx_risk` (`risk_score`),
  KEY `idx_anomaly` (`is_anomaly`),
  KEY `feedback_by_user_id` (`feedback_by_user_id`),
  CONSTRAINT `auth_events_ml_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `auth_events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `auth_events_ml_ibfk_2` FOREIGN KEY (`feedback_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_events_ml`
--

LOCK TABLES `auth_events_ml` WRITE;
/*!40000 ALTER TABLE `auth_events_ml` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_events_ml` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocking_actions`
--

DROP TABLE IF EXISTS `blocking_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocking_actions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action_uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_block_id` int DEFAULT NULL,
  `ip_address_text` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_source` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `performed_by_user_id` int DEFAULT NULL,
  `triggered_by_rule_id` int DEFAULT NULL,
  `triggered_by_event_id` bigint DEFAULT NULL,
  `agent_id` int DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `action_uuid` (`action_uuid`),
  KEY `idx_uuid` (`action_uuid`),
  KEY `idx_ip` (`ip_address_text`),
  KEY `idx_block` (`ip_block_id`),
  KEY `idx_type` (`action_type`),
  KEY `idx_created` (`created_at`),
  KEY `performed_by_user_id` (`performed_by_user_id`),
  KEY `agent_id` (`agent_id`),
  CONSTRAINT `blocking_actions_ibfk_1` FOREIGN KEY (`performed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `blocking_actions_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocking_actions`
--

LOCK TABLES `blocking_actions` WRITE;
/*!40000 ALTER TABLE `blocking_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocking_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocking_rules`
--

DROP TABLE IF EXISTS `blocking_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocking_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rule_type` enum('brute_force','ml_threshold','api_reputation','anomaly_pattern','geo_restriction','geo_anomaly','credential_stuffing','velocity','tor_detection','proxy_detection','threat_combo','repeat_offender','off_hours_anomaly','distributed_brute_force','account_takeover','behavioral_analysis','custom') COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_type` enum('block','alert','monitor') COLLATE utf8mb4_unicode_ci DEFAULT 'block',
  `is_enabled` tinyint(1) DEFAULT '1',
  `is_system_rule` tinyint(1) DEFAULT '0',
  `priority` int DEFAULT '50',
  `conditions` json NOT NULL,
  `block_duration_minutes` int DEFAULT '1440',
  `auto_unblock` tinyint(1) DEFAULT '1',
  `notify_on_trigger` tinyint(1) DEFAULT '1',
  `notification_channels` json DEFAULT NULL,
  `times_triggered` int DEFAULT '0',
  `last_triggered_at` timestamp NULL DEFAULT NULL,
  `ips_blocked_total` int DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by_user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_enabled` (`is_enabled`),
  KEY `idx_type` (`rule_type`),
  KEY `idx_priority` (`priority`),
  KEY `created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `blocking_rules_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocking_rules`
--

LOCK TABLES `blocking_rules` WRITE;
/*!40000 ALTER TABLE `blocking_rules` DISABLE KEYS */;
INSERT INTO `blocking_rules` VALUES (11,'Failed Login Alert (3 attempts)','brute_force','alert',1,1,30,'{\"failed_attempts\": 3, \"max_abuseipdb_score\": 20, \"time_window_minutes\": 10}',0,1,1,NULL,0,NULL,0,'Alert after 3 failed attempts from clean IP',NULL,'2025-12-23 08:43:31','2025-12-23 08:43:31'),(12,'Failed Login Block (5 attempts)','brute_force','block',1,1,40,'{\"failed_attempts\": 5, \"max_abuseipdb_score\": 20, \"time_window_minutes\": 10}',1440,1,1,NULL,21,'2025-12-23 11:51:30',21,'Fail2ban block after 5 failed attempts from clean IP',NULL,'2025-12-23 08:45:17','2025-12-23 11:51:30'),(13,'Persistent Attacker UFW Block','brute_force','block',1,1,50,'{\"block_method\": \"ufw\", \"failed_attempts\": 10, \"max_abuseipdb_score\": 20, \"time_window_minutes\": 1440}',43200,0,1,NULL,3,'2025-12-23 11:50:45',3,'Permanent UFW block after 10 failed in 24h',NULL,'2025-12-23 08:45:33','2025-12-23 11:50:45'),(14,'Multi-User Same IP Alert','credential_stuffing','alert',1,1,25,'{\"event_type\": \"successful\", \"unique_usernames\": 2, \"max_abuseipdb_score\": 20, \"time_window_minutes\": 60}',0,1,1,NULL,0,NULL,0,'Alert when same clean IP succeeds with multiple users',NULL,'2025-12-23 08:45:45','2025-12-23 08:45:45'),(15,'Impossible Travel Alert','geo_anomaly','alert',1,1,35,'{\"max_distance_km\": 500, \"time_window_hours\": 2, \"max_abuseipdb_score\": 20}',0,1,1,NULL,0,NULL,0,'Alert on impossible travel from clean IP',NULL,'2025-12-23 08:45:56','2025-12-23 08:45:56'),(16,'Bad Reputation IP Alert','api_reputation','alert',1,1,45,'{\"track_behavior\": true, \"min_abuseipdb_score\": 25}',0,1,1,NULL,0,NULL,0,'Alert and monitor any activity from bad reputation IP (score 25+)',NULL,'2025-12-23 08:47:42','2025-12-23 08:47:42'),(17,'Bad IP Failed Attempts Block','api_reputation','block',1,1,60,'{\"min_abuseipdb_score\": 25, \"min_failed_attempts\": 5, \"time_window_minutes\": 1440}',1440,1,1,NULL,0,NULL,0,'Block bad reputation IP (25+) after 5 failed attempts in 24h',NULL,'2025-12-23 08:47:43','2025-12-23 08:47:43'),(18,'High Risk IP Immediate Block','api_reputation','block',1,1,70,'{\"block_method\": \"ufw\", \"min_abuseipdb_score\": 50, \"min_failed_attempts\": 3, \"time_window_minutes\": 60}',43200,0,1,NULL,3,'2025-12-23 11:47:03',3,'UFW block high-risk IP (50+) after just 3 failed attempts',NULL,'2025-12-23 08:47:44','2025-12-23 11:47:03'),(19,'Off-Hours Successful Login Alert','off_hours_anomaly','alert',1,1,20,'{\"event_type\": \"successful\", \"work_end_hour\": 22, \"work_start_hour\": 6, \"check_ip_reputation\": true, \"max_abuseipdb_score\": 20}',0,1,1,NULL,0,NULL,0,'Alert when clean IP logs in successfully outside 6AM-10PM',NULL,'2025-12-23 08:48:32','2025-12-23 08:48:32'),(20,'Multi-User Off-Hours Alert','credential_stuffing','alert',1,1,26,'{\"off_hours\": true, \"event_type\": \"successful\", \"unique_usernames\": 2, \"max_abuseipdb_score\": 20, \"time_window_minutes\": 60}',0,1,1,NULL,0,NULL,0,'Alert when same clean IP succeeds with multiple users at night',NULL,'2025-12-23 09:00:15','2025-12-23 09:00:15'),(21,'Impossible Travel + Anomaly Block','geo_anomaly','block',1,1,55,'{\"min_risk_score\": 60, \"max_distance_km\": 500, \"require_anomaly\": true, \"time_window_hours\": 2}',1440,1,1,NULL,29,'2025-12-23 11:22:08',29,'Block impossible travel only if other anomalies detected',NULL,'2025-12-23 09:00:16','2025-12-23 11:22:08');
/*!40000 ALTER TABLE `blocking_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fail2ban_commands`
--

DROP TABLE IF EXISTS `fail2ban_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fail2ban_commands` (
  `id` int NOT NULL AUTO_INCREMENT,
  `command_uuid` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agent_id` int NOT NULL,
  `command_type` enum('ban','unban') COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jail_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'sshd',
  `bantime_seconds` int DEFAULT '0',
  `status` enum('pending','sent','completed','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `result_message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `sent_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `command_uuid` (`command_uuid`),
  KEY `idx_agent_status` (`agent_id`,`status`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fail2ban_commands_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fail2ban_commands`
--

LOCK TABLES `fail2ban_commands` WRITE;
/*!40000 ALTER TABLE `fail2ban_commands` DISABLE KEYS */;
/*!40000 ALTER TABLE `fail2ban_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fail2ban_events`
--

DROP TABLE IF EXISTS `fail2ban_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fail2ban_events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `agent_id` int NOT NULL,
  `event_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jail_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'sshd',
  `failures` int DEFAULT '0',
  `bantime_seconds` int DEFAULT '0',
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `raw_log` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_agent` (`agent_id`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_type` (`event_type`),
  KEY `idx_timestamp` (`timestamp`),
  CONSTRAINT `fail2ban_events_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fail2ban_events`
--

LOCK TABLES `fail2ban_events` WRITE;
/*!40000 ALTER TABLE `fail2ban_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `fail2ban_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fail2ban_state`
--

DROP TABLE IF EXISTS `fail2ban_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fail2ban_state` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_id` int NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jail_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'sshd',
  `banned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `bantime_seconds` int DEFAULT '0',
  `failures` int DEFAULT '0',
  `last_sync` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_agent_ip_jail` (`agent_id`,`ip_address`,`jail_name`),
  KEY `idx_agent` (`agent_id`),
  KEY `idx_ip` (`ip_address`),
  CONSTRAINT `fail2ban_state_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fail2ban_state`
--

LOCK TABLES `fail2ban_state` WRITE;
/*!40000 ALTER TABLE `fail2ban_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `fail2ban_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guide_steps`
--

DROP TABLE IF EXISTS `guide_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guide_steps` (
  `id` int NOT NULL AUTO_INCREMENT,
  `step_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `step_order` int NOT NULL,
  `is_required` tinyint(1) DEFAULT '0',
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `step_key` (`step_key`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guide_steps`
--

LOCK TABLES `guide_steps` WRITE;
/*!40000 ALTER TABLE `guide_steps` DISABLE KEYS */;
INSERT INTO `guide_steps` VALUES (1,'welcome','Welcome to SSH Guardian','A Research Project for SME Cybersecurity',1,1,'&#128737;',NULL,'2025-12-06 17:57:44'),(2,'architecture','System Architecture','5-Layer Security Pipeline',2,1,'&#127959;',NULL,'2025-12-06 17:57:44'),(3,'deployment','Agent Deployment','Install and Configure Monitoring Agents',3,1,'&#128640;',NULL,'2025-12-06 17:57:44'),(4,'monitoring','Live Events Monitoring','Real-time Authentication Event Stream',4,1,'&#128200;',NULL,'2025-12-06 17:57:44'),(5,'firewall','Firewall Management','UFW Integration and IP Blocking',5,1,'&#128295;',NULL,'2025-12-06 17:57:44'),(6,'intelligence','Threat Intelligence & ML','Advanced Detection Capabilities',6,1,'&#129302;',NULL,'2025-12-06 17:57:44');
/*!40000 ALTER TABLE `guide_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `integrations`
--

DROP TABLE IF EXISTS `integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `integrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `integration_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_enabled` tinyint(1) DEFAULT '0',
  `config` json DEFAULT NULL,
  `credentials` json DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `last_error` text COLLATE utf8mb4_unicode_ci,
  `error_count` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_type` (`integration_type`),
  KEY `idx_enabled` (`is_enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `integrations`
--

LOCK TABLES `integrations` WRITE;
/*!40000 ALTER TABLE `integrations` DISABLE KEYS */;
INSERT INTO `integrations` VALUES (1,'telegram','Telegram Bot',1,'{\"chat_id\": \"5926359372\", \"enabled\": \"true\"}','{\"bot_token\": \"8270421918:AAEeAgI5sxsEpN3pHW1_4PI7A8pQG5xSlIU\"}','2025-12-19 17:45:30',NULL,0,'2025-12-05 00:39:01','2025-12-19 17:45:30'),(2,'abuseipdb','AbuseIPDB',1,'{\"enabled\": \"true\", \"rate_limit_day\": \"1000\", \"rate_limit_minute\": \"30\"}','{\"api_key\": \"48515d5fd62e4fb01568c75e8dc431b303ad0da9495112ba3670dbb9d694d0451e4baf5258f33be9\"}','2025-12-23 15:16:48',NULL,0,'2025-12-05 00:39:01','2025-12-23 15:16:48'),(3,'virustotal','VirusTotal',1,'{\"enabled\": \"true\", \"rate_limit_day\": \"250\", \"rate_limit_minute\": \"4\"}','{\"api_key\": \"0a98da96528d5c732b8ed212490d0ccf1cefebb3670b30705c4d2b27ae276d0d\"}','2025-12-19 05:42:49',NULL,0,'2025-12-05 00:39:01','2025-12-19 05:42:49'),(4,'shodan','Shodan',1,'{\"enabled\": \"true\", \"high_risk_only\": \"true\", \"rate_limit_day\": \"3\", \"rate_limit_month\": \"100\"}','{\"api_key\": \"SqaZfXzEDiC6sj2jQoZGQX2iz2ustE3V\"}','2025-12-19 05:43:15',NULL,0,'2025-12-05 00:39:01','2025-12-19 05:43:15'),(5,'smtp','Email (SMTP)',1,'{\"host\": \"mail.hyperconnect.my\", \"port\": \"25\", \"user\": \"sohell.ranaa@hyperconnect.my\", \"use_tls\": \"false\", \"from_name\": \"SSH Guardian Security\", \"from_email\": \"sohell.ranaa@hyperconnect.my\"}','{\"password\": \"@Sohel@2025@\"}','2025-12-23 15:16:56',NULL,0,'2025-12-05 00:39:01','2025-12-23 15:16:56'),(6,'ipapi','IP-API',1,'{\"enabled\": \"true\", \"use_as_primary\": \"false\", \"rate_limit_minute\": \"45\"}',NULL,'2025-12-19 05:32:04',NULL,0,'2025-12-05 00:39:01','2025-12-19 05:32:04'),(7,'freeipapi','FreeIPAPI',1,'{\"enabled\": \"true\", \"use_as_primary\": \"true\", \"cache_ttl_hours\": \"24\", \"rate_limit_minute\": \"60\"}',NULL,'2025-12-19 05:32:49',NULL,0,'2025-12-06 01:08:30','2025-12-19 05:32:49'),(8,'greynoise','GreyNoise',0,'{\"enabled\": \"true\", \"use_community_api\": \"true\"}','{\"api_key\": \"\"}','2025-12-20 22:23:37',NULL,0,'2025-12-20 21:48:52','2025-12-20 22:23:37');
/*!40000 ALTER TABLE `integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_blocks`
--

DROP TABLE IF EXISTS `ip_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_blocks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `ip_address_text` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_range_cidr` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `block_reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `block_source` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blocking_rule_id` int DEFAULT NULL,
  `trigger_event_id` bigint DEFAULT NULL,
  `agent_id` int DEFAULT NULL,
  `geo_id` int DEFAULT NULL,
  `failed_attempts` int DEFAULT '0',
  `risk_score` tinyint unsigned DEFAULT NULL,
  `threat_level` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `blocked_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `unblock_at` timestamp NULL DEFAULT NULL,
  `auto_unblock` tinyint(1) DEFAULT '1',
  `unblocked_at` timestamp NULL DEFAULT NULL,
  `unblocked_by_user_id` int DEFAULT NULL,
  `unblock_reason` text COLLATE utf8mb4_unicode_ci,
  `is_simulation` tinyint(1) DEFAULT '0',
  `simulation_run_id` int DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_by_user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ip` (`ip_address_text`),
  KEY `idx_active` (`is_active`),
  KEY `idx_source` (`block_source`),
  KEY `idx_agent` (`agent_id`),
  KEY `idx_blocked_at` (`blocked_at`),
  KEY `idx_unblock_at` (`unblock_at`),
  KEY `geo_id` (`geo_id`),
  KEY `created_by_user_id` (`created_by_user_id`),
  KEY `unblocked_by_user_id` (`unblocked_by_user_id`),
  CONSTRAINT `ip_blocks_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ip_blocks_ibfk_2` FOREIGN KEY (`geo_id`) REFERENCES `ip_geolocation` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ip_blocks_ibfk_3` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ip_blocks_ibfk_4` FOREIGN KEY (`unblocked_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_blocks`
--

LOCK TABLES `ip_blocks` WRITE;
/*!40000 ALTER TABLE `ip_blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_geolocation`
--

DROP TABLE IF EXISTS `ip_geolocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_geolocation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `ip_address_text` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_version` tinyint DEFAULT '4',
  `country_code` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `timezone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asn` int DEFAULT NULL,
  `asn_org` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `connection_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_proxy` tinyint(1) DEFAULT '0',
  `is_vpn` tinyint(1) DEFAULT '0',
  `is_tor` tinyint(1) DEFAULT '0',
  `is_datacenter` tinyint(1) DEFAULT '0',
  `is_hosting` tinyint(1) DEFAULT '0',
  `abuseipdb_score` int DEFAULT NULL,
  `abuseipdb_reports` int DEFAULT NULL,
  `abuseipdb_last_reported` timestamp NULL DEFAULT NULL,
  `abuseipdb_checked_at` timestamp NULL DEFAULT NULL,
  `virustotal_positives` int DEFAULT NULL,
  `virustotal_total` int DEFAULT NULL,
  `virustotal_checked_at` timestamp NULL DEFAULT NULL,
  `shodan_ports` text COLLATE utf8mb4_unicode_ci,
  `shodan_vulns` text COLLATE utf8mb4_unicode_ci,
  `shodan_checked_at` timestamp NULL DEFAULT NULL,
  `threat_level` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'unknown',
  `threat_categories` json DEFAULT NULL,
  `lookup_count` int DEFAULT '1',
  `first_seen` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_seen` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `cache_expires_at` timestamp NULL DEFAULT NULL,
  `greynoise_noise` tinyint(1) DEFAULT NULL COMMENT 'True if IP is known internet scanner',
  `greynoise_riot` tinyint(1) DEFAULT NULL COMMENT 'True if IP is known benign service (CDN, search engine)',
  `greynoise_classification` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'benign, malicious, or unknown',
  `greynoise_checked_at` timestamp NULL DEFAULT NULL COMMENT 'When GreyNoise was last checked',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  UNIQUE KEY `ip_address_text` (`ip_address_text`),
  KEY `idx_ip_text` (`ip_address_text`),
  KEY `idx_country` (`country_code`),
  KEY `idx_threat` (`threat_level`),
  KEY `idx_asn` (`asn`),
  KEY `idx_ip_geolocation_greynoise` (`greynoise_noise`,`greynoise_riot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_geolocation`
--

LOCK TABLES `ip_geolocation` WRITE;
/*!40000 ALTER TABLE `ip_geolocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_geolocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_threat_intelligence`
--

DROP TABLE IF EXISTS `ip_threat_intelligence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_threat_intelligence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip_address_text` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `geo_id` int DEFAULT NULL,
  `abuseipdb_score` int DEFAULT NULL COMMENT '0-100 confidence of abuse',
  `abuseipdb_confidence` int DEFAULT NULL,
  `abuseipdb_reports` int DEFAULT NULL COMMENT 'Number of abuse reports',
  `abuseipdb_last_reported` timestamp NULL DEFAULT NULL,
  `abuseipdb_categories` json DEFAULT NULL COMMENT 'Array of abuse categories',
  `abuseipdb_checked_at` timestamp NULL DEFAULT NULL,
  `shodan_ports` json DEFAULT NULL COMMENT 'Open ports detected',
  `shodan_tags` json DEFAULT NULL COMMENT 'Tags like honeypot, vpn, etc',
  `shodan_vulns` json DEFAULT NULL COMMENT 'Known vulnerabilities',
  `shodan_last_update` timestamp NULL DEFAULT NULL,
  `shodan_checked_at` timestamp NULL DEFAULT NULL,
  `virustotal_positives` int DEFAULT NULL COMMENT 'Detection count',
  `virustotal_total` int DEFAULT NULL COMMENT 'Total engines checked',
  `virustotal_detected_urls` json DEFAULT NULL,
  `virustotal_checked_at` timestamp NULL DEFAULT NULL,
  `virustotal_malicious` int DEFAULT '0',
  `overall_threat_level` enum('clean','low','medium','high','critical') COLLATE utf8mb4_unicode_ci DEFAULT 'clean',
  `threat_confidence` decimal(5,4) DEFAULT NULL COMMENT 'Confidence in assessment',
  `first_seen` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_seen` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_tor` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address_text` (`ip_address_text`),
  KEY `idx_threat_level` (`overall_threat_level`),
  KEY `idx_abuseipdb` (`abuseipdb_score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_threat_intelligence`
--

LOCK TABLES `ip_threat_intelligence` WRITE;
/*!40000 ALTER TABLE `ip_threat_intelligence` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_threat_intelligence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `live_simulation_runs`
--

DROP TABLE IF EXISTS `live_simulation_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `live_simulation_runs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `target_id` int DEFAULT NULL,
  `run_uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `simulation_run_id` int DEFAULT NULL,
  `agent_id` int NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `events_sent` int DEFAULT '0',
  `events_detected` int DEFAULT '0',
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `results` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `scenario_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scenario_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_count` int DEFAULT '0',
  `injected_at` timestamp NULL DEFAULT NULL,
  `detected_at` timestamp NULL DEFAULT NULL,
  `blocked_at` timestamp NULL DEFAULT NULL,
  `fail2ban_block_id` int DEFAULT NULL,
  `ml_block_id` int DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `run_uuid` (`run_uuid`),
  KEY `idx_uuid` (`run_uuid`),
  KEY `idx_status` (`status`),
  KEY `simulation_run_id` (`simulation_run_id`),
  KEY `agent_id` (`agent_id`),
  CONSTRAINT `live_simulation_runs_ibfk_1` FOREIGN KEY (`simulation_run_id`) REFERENCES `simulation_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `live_simulation_runs_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `live_simulation_runs`
--

LOCK TABLES `live_simulation_runs` WRITE;
/*!40000 ALTER TABLE `live_simulation_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `live_simulation_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_sources`
--

DROP TABLE IF EXISTS `log_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_sources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `source_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pattern_regex` text COLLATE utf8mb4_unicode_ci,
  `is_enabled` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_name` (`source_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_sources`
--

LOCK TABLES `log_sources` WRITE;
/*!40000 ALTER TABLE `log_sources` DISABLE KEYS */;
INSERT INTO `log_sources` VALUES (1,'primary_agents','agent',NULL,NULL,1,'2025-12-04 17:23:03','2025-12-04 17:23:03'),(2,'dashboard_generator','synthetic',NULL,NULL,1,'2025-12-04 17:23:03','2025-12-04 17:23:03'),(3,'simulation_engine','simulation',NULL,NULL,1,'2025-12-04 17:23:03','2025-12-04 17:23:03');
/*!40000 ALTER TABLE `log_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml_benefits_metrics`
--

DROP TABLE IF EXISTS `ml_benefits_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_benefits_metrics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `total_events_analyzed` int DEFAULT '0',
  `threats_detected_ml` int DEFAULT '0',
  `high_risk_events` int DEFAULT '0',
  `first_attempt_detections` int DEFAULT '0',
  `threats_would_miss_fail2ban` int DEFAULT '0',
  `events_under_threshold` int DEFAULT '0',
  `false_positives_prevented` int DEFAULT '0',
  `auto_escalations_to_ufw` int DEFAULT '0',
  `distributed_attacks_detected` int DEFAULT '0',
  `time_saved_minutes` int DEFAULT '0',
  `manual_reviews_prevented` int DEFAULT '0',
  `detection_improvement_pct` decimal(5,2) DEFAULT NULL,
  `false_positive_reduction_pct` decimal(5,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`),
  KEY `idx_benefits_date` (`date` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_benefits_metrics`
--

LOCK TABLES `ml_benefits_metrics` WRITE;
/*!40000 ALTER TABLE `ml_benefits_metrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml_benefits_metrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml_comparison_results`
--

DROP TABLE IF EXISTS `ml_comparison_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_comparison_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `run_id` int DEFAULT NULL,
  `model_name` varchar(100) NOT NULL,
  `algorithm` varchar(50) NOT NULL,
  `model_version` varchar(50) DEFAULT NULL,
  `model_file_path` varchar(255) DEFAULT NULL,
  `training_samples` int NOT NULL,
  `testing_samples` int NOT NULL,
  `feature_count` int NOT NULL,
  `hyperparameters` json DEFAULT NULL,
  `accuracy` decimal(10,6) NOT NULL,
  `precision_score` decimal(10,6) NOT NULL,
  `recall_score` decimal(10,6) NOT NULL,
  `f1_score` decimal(10,6) NOT NULL,
  `roc_auc` decimal(10,6) NOT NULL,
  `true_positives` int NOT NULL,
  `true_negatives` int NOT NULL,
  `false_positives` int NOT NULL,
  `false_negatives` int NOT NULL,
  `confusion_matrix` json DEFAULT NULL,
  `specificity` decimal(10,6) DEFAULT NULL,
  `balanced_accuracy` decimal(10,6) DEFAULT NULL,
  `matthews_correlation` decimal(10,6) DEFAULT NULL,
  `training_time_seconds` decimal(10,3) DEFAULT NULL,
  `prediction_time_ms` decimal(10,3) DEFAULT NULL,
  `memory_usage_mb` decimal(10,2) DEFAULT NULL,
  `feature_importance` json DEFAULT NULL,
  `cv_scores` json DEFAULT NULL,
  `cv_mean` decimal(10,6) DEFAULT NULL,
  `cv_std` decimal(10,6) DEFAULT NULL,
  `classification_report` json DEFAULT NULL,
  `is_best_model` tinyint(1) DEFAULT '0',
  `selection_reason` text,
  `trained_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_algorithm` (`algorithm`),
  KEY `idx_f1_score` (`f1_score`),
  KEY `idx_is_best` (`is_best_model`),
  KEY `idx_run_id` (`run_id`),
  CONSTRAINT `fk_run_id` FOREIGN KEY (`run_id`) REFERENCES `ml_training_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_comparison_results`
--

LOCK TABLES `ml_comparison_results` WRITE;
/*!40000 ALTER TABLE `ml_comparison_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml_comparison_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml_models`
--

DROP TABLE IF EXISTS `ml_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_models` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model_uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `algorithm` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'training',
  `is_active` tinyint(1) DEFAULT '0',
  `model_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_size_bytes` bigint DEFAULT NULL,
  `hyperparameters` json DEFAULT NULL,
  `feature_config` json DEFAULT NULL,
  `feature_names` text COLLATE utf8mb4_unicode_ci,
  `training_run_id` int DEFAULT NULL,
  `accuracy` decimal(5,4) DEFAULT NULL,
  `precision_score` decimal(5,4) DEFAULT NULL,
  `recall_score` decimal(5,4) DEFAULT NULL,
  `f1_score` decimal(5,4) DEFAULT NULL,
  `auc_roc` decimal(5,4) DEFAULT NULL,
  `predictions_count` bigint DEFAULT '0',
  `avg_inference_time_ms` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `promoted_at` timestamp NULL DEFAULT NULL,
  `deprecated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `model_uuid` (`model_uuid`),
  KEY `idx_uuid` (`model_uuid`),
  KEY `idx_status` (`status`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_models`
--

LOCK TABLES `ml_models` WRITE;
/*!40000 ALTER TABLE `ml_models` DISABLE KEYS */;
INSERT INTO `ml_models` VALUES (11,'5b2e1b74-df2e-11f0-b7ce-0050565e9ee5','random_forest_20251221_074932','random_forest','1.0','candidate',0,NULL,NULL,NULL,NULL,NULL,NULL,1.0000,1.0000,1.0000,1.0000,1.0000,0,NULL,'2025-12-20 23:58:51','2025-12-22 12:08:10',NULL,NULL),(12,'5b2eb1c2-df2e-11f0-b7ce-0050565e9ee5','xgboost_20251221_075439','xgboost','1.0','candidate',0,NULL,NULL,NULL,NULL,NULL,NULL,0.9999,0.9999,1.0000,0.9999,1.0000,0,NULL,'2025-12-20 23:58:51','2025-12-22 12:04:23',NULL,NULL),(13,'5b2eb4f7-df2e-11f0-b7ce-0050565e9ee5','lightgbm_20251221_075851','lightgbm','1.0','candidate',0,NULL,NULL,NULL,NULL,NULL,NULL,1.0000,1.0000,1.0000,1.0000,1.0000,0,NULL,'2025-12-20 23:58:51','2025-12-22 12:04:23',NULL,NULL),(14,'609fcfae-df2e-11f0-b7ce-0050565e9ee5','random_forest_20251221_121446','random_forest','1.0','candidate',0,NULL,NULL,NULL,NULL,NULL,NULL,0.9989,0.9981,0.9997,0.9989,1.0000,0,NULL,'2025-12-21 04:27:10','2025-12-22 12:04:33',NULL,NULL),(15,'60a023c8-df2e-11f0-b7ce-0050565e9ee5','xgboost_20251221_122054','xgboost','1.0','candidate',0,NULL,NULL,NULL,NULL,NULL,NULL,0.9989,0.9983,0.9995,0.9989,1.0000,0,NULL,'2025-12-21 04:27:10','2025-12-22 12:04:33',NULL,NULL),(16,'60a027b4-df2e-11f0-b7ce-0050565e9ee5','lightgbm_20251221_122710','lightgbm','1.0','candidate',0,NULL,NULL,NULL,NULL,NULL,NULL,0.9989,0.9984,0.9994,0.9989,1.0000,0,NULL,'2025-12-21 04:27:10','2025-12-22 12:04:33',NULL,NULL),(17,'60a02b0f-df2e-11f0-b7ce-0050565e9ee5','random_forest_20251221_164349','random_forest','1.0','candidate',0,NULL,NULL,NULL,NULL,NULL,NULL,0.9988,0.9980,0.9996,0.9988,0.9999,0,NULL,'2025-12-21 08:54:56','2025-12-22 12:04:33',NULL,NULL),(18,'60a02d11-df2e-11f0-b7ce-0050565e9ee5','xgboost_20251221_165015','xgboost','1.0','candidate',0,NULL,NULL,NULL,NULL,NULL,NULL,0.9988,0.9981,0.9995,0.9988,1.0000,0,NULL,'2025-12-21 08:54:56','2025-12-22 12:04:33',NULL,NULL),(19,'60a02fea-df2e-11f0-b7ce-0050565e9ee5','lightgbm_20251221_165456','lightgbm','1.0','candidate',0,NULL,NULL,NULL,NULL,NULL,NULL,0.9986,0.9976,0.9996,0.9986,1.0000,0,NULL,'2025-12-21 08:54:56','2025-12-22 12:04:33',NULL,NULL),(20,'60a032e8-df2e-11f0-b7ce-0050565e9ee5','random_forest_20251221_231343','random_forest','1.0','production',1,'/home/rana-workspace/ssh_guardian_v3.0/ml_models/random_forest_20251221_231343.pkl',NULL,NULL,NULL,NULL,NULL,0.9690,0.9681,0.9686,0.9684,0.9701,0,NULL,'2025-12-21 15:25:25','2025-12-22 13:41:15',NULL,NULL),(21,'60a0360a-df2e-11f0-b7ce-0050565e9ee5','xgboost_20251221_232022','xgboost','1.0','candidate',0,NULL,NULL,NULL,NULL,NULL,NULL,0.9689,0.9681,0.9685,0.9683,0.9703,0,NULL,'2025-12-21 15:25:25','2025-12-22 12:04:33',NULL,NULL),(22,'60a03834-df2e-11f0-b7ce-0050565e9ee5','lightgbm_20251221_232525','lightgbm','1.0','candidate',0,NULL,NULL,NULL,NULL,NULL,NULL,0.9687,0.9678,0.9685,0.9681,0.9702,0,NULL,'2025-12-21 15:25:25','2025-12-22 12:04:33',NULL,NULL);
/*!40000 ALTER TABLE `ml_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml_testing_data`
--

DROP TABLE IF EXISTS `ml_testing_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_testing_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_uuid` char(36) NOT NULL,
  `timestamp` timestamp NOT NULL,
  `event_type` varchar(20) NOT NULL,
  `auth_method` varchar(20) DEFAULT 'password',
  `failure_reason` varchar(100) DEFAULT NULL,
  `source_ip` varchar(45) NOT NULL,
  `source_port` int DEFAULT NULL,
  `target_server` varchar(255) DEFAULT NULL,
  `target_port` int DEFAULT '22',
  `target_username` varchar(100) DEFAULT NULL,
  `country_code` char(2) DEFAULT NULL,
  `country_name` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,6) DEFAULT NULL,
  `longitude` decimal(10,6) DEFAULT NULL,
  `is_private_ip` tinyint(1) DEFAULT '0',
  `is_vpn` tinyint(1) DEFAULT '0',
  `is_proxy` tinyint(1) DEFAULT '0',
  `is_tor` tinyint(1) DEFAULT '0',
  `is_datacenter` tinyint(1) DEFAULT '0',
  `is_hosting` tinyint(1) DEFAULT '0',
  `abuseipdb_score` int DEFAULT '0',
  `virustotal_positives` int DEFAULT '0',
  `virustotal_total` int DEFAULT '0',
  `greynoise_classification` varchar(20) DEFAULT NULL,
  `threat_level` varchar(20) DEFAULT 'clean',
  `scenario_type` varchar(50) NOT NULL,
  `is_malicious` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_uuid` (`event_uuid`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_source_ip` (`source_ip`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_scenario` (`scenario_type`),
  KEY `idx_malicious` (`is_malicious`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_testing_data`
--

LOCK TABLES `ml_testing_data` WRITE;
/*!40000 ALTER TABLE `ml_testing_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml_testing_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml_training_data`
--

DROP TABLE IF EXISTS `ml_training_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_training_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_uuid` char(36) NOT NULL,
  `timestamp` timestamp NOT NULL,
  `event_type` varchar(20) NOT NULL,
  `auth_method` varchar(20) DEFAULT 'password',
  `failure_reason` varchar(100) DEFAULT NULL,
  `source_ip` varchar(45) NOT NULL,
  `source_port` int DEFAULT NULL,
  `target_server` varchar(255) DEFAULT NULL,
  `target_port` int DEFAULT '22',
  `target_username` varchar(100) DEFAULT NULL,
  `country_code` char(2) DEFAULT NULL,
  `country_name` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,6) DEFAULT NULL,
  `longitude` decimal(10,6) DEFAULT NULL,
  `is_private_ip` tinyint(1) DEFAULT '0',
  `is_vpn` tinyint(1) DEFAULT '0',
  `is_proxy` tinyint(1) DEFAULT '0',
  `is_tor` tinyint(1) DEFAULT '0',
  `is_datacenter` tinyint(1) DEFAULT '0',
  `is_hosting` tinyint(1) DEFAULT '0',
  `abuseipdb_score` int DEFAULT '0',
  `virustotal_positives` int DEFAULT '0',
  `virustotal_total` int DEFAULT '0',
  `greynoise_classification` varchar(20) DEFAULT NULL,
  `threat_level` varchar(20) DEFAULT 'clean',
  `scenario_type` varchar(50) NOT NULL,
  `is_malicious` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_uuid` (`event_uuid`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_source_ip` (`source_ip`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_scenario` (`scenario_type`),
  KEY `idx_malicious` (`is_malicious`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_training_data`
--

LOCK TABLES `ml_training_data` WRITE;
/*!40000 ALTER TABLE `ml_training_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml_training_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml_training_iterations`
--

DROP TABLE IF EXISTS `ml_training_iterations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_training_iterations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `run_id` int NOT NULL,
  `iteration_number` int NOT NULL DEFAULT '1',
  `algorithm` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hyperparameters` json DEFAULT NULL,
  `accuracy` decimal(10,6) NOT NULL,
  `precision_score` decimal(10,6) NOT NULL,
  `recall_score` decimal(10,6) NOT NULL,
  `f1_score` decimal(10,6) NOT NULL,
  `roc_auc` decimal(10,6) NOT NULL,
  `specificity` decimal(10,6) DEFAULT NULL,
  `balanced_accuracy` decimal(10,6) DEFAULT NULL,
  `matthews_correlation` decimal(10,6) DEFAULT NULL,
  `true_positives` int DEFAULT '0',
  `true_negatives` int DEFAULT '0',
  `false_positives` int DEFAULT '0',
  `false_negatives` int DEFAULT '0',
  `training_samples` int DEFAULT '0',
  `testing_samples` int DEFAULT '0',
  `training_time_seconds` decimal(10,3) DEFAULT NULL,
  `prediction_time_ms` decimal(10,3) DEFAULT NULL,
  `memory_usage_mb` decimal(10,2) DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_best_iteration` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_iteration_run` (`run_id`),
  KEY `idx_iteration_algorithm` (`algorithm`),
  KEY `idx_iteration_f1` (`f1_score` DESC),
  KEY `idx_iteration_created` (`created_at`),
  CONSTRAINT `fk_iteration_run` FOREIGN KEY (`run_id`) REFERENCES `ml_training_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_training_iterations`
--

LOCK TABLES `ml_training_iterations` WRITE;
/*!40000 ALTER TABLE `ml_training_iterations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml_training_iterations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml_training_runs`
--

DROP TABLE IF EXISTS `ml_training_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_training_runs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `run_uuid` char(36) NOT NULL,
  `run_name` varchar(100) DEFAULT NULL,
  `total_events_generated` int DEFAULT NULL,
  `training_events` int DEFAULT NULL,
  `testing_events` int DEFAULT NULL,
  `benign_count` int DEFAULT NULL,
  `malicious_count` int DEFAULT NULL,
  `scenario_distribution` json DEFAULT NULL,
  `feature_names` json DEFAULT NULL,
  `feature_count` int DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `error_message` text,
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `run_uuid` (`run_uuid`),
  KEY `idx_status` (`status`),
  KEY `idx_started` (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_training_runs`
--

LOCK TABLES `ml_training_runs` WRITE;
/*!40000 ALTER TABLE `ml_training_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml_training_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_rules`
--

DROP TABLE IF EXISTS `notification_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conditions` json DEFAULT NULL,
  `channels` json NOT NULL,
  `message_template` text COLLATE utf8mb4_unicode_ci,
  `is_enabled` tinyint(1) DEFAULT '1',
  `cooldown_minutes` int DEFAULT '5',
  `last_triggered_at` timestamp NULL DEFAULT NULL,
  `times_triggered` int DEFAULT '0',
  `created_by_user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_event` (`event_type`),
  KEY `idx_enabled` (`is_enabled`),
  KEY `created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `notification_rules_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_rules`
--

LOCK TABLES `notification_rules` WRITE;
/*!40000 ALTER TABLE `notification_rules` DISABLE KEYS */;
INSERT INTO `notification_rules` VALUES (1,'Critical IP Block Alert','ip_blocked','{\"min_risk_score\": 80}','[\"telegram\"]','🚫 <b>IP Blocked</b>\n\n<b>IP:</b> {{ip_address}}\n<b>Reason:</b> {{block_reason}}\n<b>Duration:</b> {{block_duration}}\n<b>Location:</b> {{country}}\n\n<i>{{timestamp}}</i>',1,5,NULL,0,NULL,'2025-12-04 17:23:03','2025-12-23 22:36:51'),(2,'Brute Force Attack Alert','brute_force_detected','{\"min_attempts\": 5, \"time_window_minutes\": 10}','[\"telegram\", \"email\"]','⚠️ <b>Brute Force Attack</b>\n\n<b>IP:</b> {{ip_address}}\n<b>Attempts:</b> {{attempt_count}}\n<b>Target User:</b> {{username}}\n<b>Location:</b> {{city}}, {{country}}\n\n<i>Event #{{event_id}} | {{timestamp}}</i>',1,1,NULL,0,NULL,'2025-12-05 01:54:27','2025-12-23 22:36:51'),(3,'High Risk IP Detected','high_risk_detected','{\"min_risk_score\": 70}','[\"telegram\"]','🚨 <b>High Risk IP Detected</b>\n\n<b>IP:</b> {{ip_address}}\n<b>User:</b> {{username}}\n<b>Risk:</b> {{risk_score}}/100 ({{threat_type}})\n<b>Location:</b> {{city}}, {{country}}\n\n<b>Threat Intel:</b>\n• AbuseIPDB: {{abuseipdb_score}}/100\n• VirusTotal: {{virustotal_positives}} detections\n\n<i>Event #{{event_id}} | {{timestamp}}</i>',1,5,NULL,0,NULL,'2025-12-05 01:57:00','2025-12-23 22:36:51'),(4,'Agent Offline Alert','agent_offline','{\"offline_minutes\": 5}','[\"telegram\", \"email\"]','🔴 <b>Agent Offline</b>\n\n<b>Agent:</b> {{agent_name}}\n<b>Host:</b> {{hostname}}\n<b>Last Seen:</b> {{last_seen}}\n\n<i>{{timestamp}}</i>',1,10,NULL,0,NULL,'2025-12-05 01:57:45','2025-12-23 22:36:51'),(6,'IP Blocked Notification','ip_blocked',NULL,'[\"telegram\"]','🚫 <b>IP Blocked</b>\n\n<b>IP:</b> {{ip_address}}\n<b>Reason:</b> {{block_reason}}\n<b>Duration:</b> {{block_duration}}\n<b>Location:</b> {{country}}\n\n<i>{{timestamp}}</i>',1,1,NULL,0,NULL,'2025-12-05 02:02:39','2025-12-23 22:36:51'),(8,'System Error Alert','system_error',NULL,'[\"telegram\", \"email\"]','⛔ <b>System Error</b>\n\n<b>Component:</b> {{component}}\n<b>Severity:</b> {{severity}}\n<b>Error:</b> {{error_message}}\n\n<i>{{timestamp}}</i>',1,5,NULL,0,NULL,'2025-12-05 02:02:39','2025-12-23 22:36:51'),(9,'ML Behavioral Anomaly','anomaly_detected',NULL,'[\"telegram\"]','🧠 <b>Behavioral Anomaly Detected</b>\n\n<b>User:</b> {{username}}\n<b>IP:</b> {{ip_address}}\n<b>Score:</b> {{risk_score}}/100\n<b>Location:</b> {{city}}, {{country}}\n\n<b>Anomaly Factors:</b>\n{{anomaly_details}}\n\n<i>Event #{{event_id}} | {{timestamp}}</i>',1,5,NULL,0,NULL,'2025-12-20 02:19:05','2025-12-23 22:36:51');
/*!40000 ALTER TABLE `notification_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `notification_rule_id` int DEFAULT NULL,
  `channel` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ml_score` int DEFAULT '0',
  `ml_factors` json DEFAULT NULL,
  `geo_data` json DEFAULT NULL,
  `agent_id` int DEFAULT NULL,
  `is_acknowledged` tinyint(1) DEFAULT '0',
  `acknowledged_by` int DEFAULT NULL,
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `action_taken` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_security_alert` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rule` (`notification_rule_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created` (`created_at`),
  KEY `idx_notifications_security_alerts` (`is_security_alert`,`is_acknowledged`,`created_at` DESC),
  KEY `idx_notifications_ip_alerts` (`ip_address`,`is_security_alert`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`notification_rule_id`) REFERENCES `notification_rules` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raw_ssh_logs`
--

DROP TABLE IF EXISTS `raw_ssh_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `raw_ssh_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `server_name` varchar(50) NOT NULL COMMENT 'Server hostname where log was collected',
  `server_location` varchar(100) DEFAULT NULL COMMENT 'Datacenter/location (e.g., BD-DHK-DC1)',
  `raw_log` text NOT NULL COMMENT 'Original auth.log line',
  `log_timestamp` datetime NOT NULL COMMENT 'Timestamp parsed from log',
  `collected_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'When log was collected',
  `collection_batch` varchar(36) DEFAULT NULL COMMENT 'Batch UUID for grouping collections',
  `log_source` varchar(50) DEFAULT 'auth.log' COMMENT 'Source file (auth.log, secure, etc.)',
  PRIMARY KEY (`id`),
  KEY `idx_server` (`server_name`),
  KEY `idx_timestamp` (`log_timestamp`),
  KEY `idx_batch` (`collection_batch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Raw SSH authentication logs collected from production servers';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raw_ssh_logs`
--

LOCK TABLES `raw_ssh_logs` WRITE;
/*!40000 ALTER TABLE `raw_ssh_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `raw_ssh_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `permissions` json DEFAULT NULL,
  `is_system_role` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Super Admin','Full system access with all permissions','{\"audit_logs\": true, \"ip_management\": true, \"blocking_rules\": true, \"system_settings\": true, \"user_management\": true, \"agent_management\": true, \"dashboard_access\": true, \"simulation_management\": true, \"notification_management\": true}',0,'2025-12-04 17:23:03','2025-12-04 17:23:03'),(2,'Admin','Administrative access without user management','{\"ip_management\": true, \"blocking_rules\": true, \"agent_management\": true, \"dashboard_access\": true, \"simulation_management\": true, \"notification_management\": true}',0,'2025-12-04 17:23:03','2025-12-04 17:23:03'),(3,'Analyst','Read access with basic simulation capabilities','{\"dashboard_access\": true, \"simulation_management\": true}',0,'2025-12-04 17:23:03','2025-12-04 17:23:03'),(4,'Viewer','Read-only dashboard access','{\"dashboard_access\": true}',0,'2025-12-04 17:23:03','2025-12-04 17:23:03');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `simulation_ip_pool`
--

DROP TABLE IF EXISTS `simulation_ip_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `simulation_ip_pool` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'malicious',
  `country_code` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `threat_score` int DEFAULT NULL,
  `attack_patterns` json DEFAULT NULL,
  `times_used` int DEFAULT '0',
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_ip` (`ip_address`),
  KEY `idx_type` (`ip_type`),
  KEY `idx_country` (`country_code`)
) ENGINE=InnoDB AUTO_INCREMENT=1710 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `simulation_ip_pool`
--

LOCK TABLES `simulation_ip_pool` WRITE;
/*!40000 ALTER TABLE `simulation_ip_pool` DISABLE KEYS */;
INSERT INTO `simulation_ip_pool` VALUES (1,'1.13.19.219','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(2,'1.161.45.32','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(3,'1.194.200.251','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(4,'1.214.197.163','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(5,'1.214.42.172','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(6,'1.222.50.93','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(7,'1.226.83.51','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(8,'1.226.83.71','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(9,'1.234.83.55','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(10,'1.238.106.229','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(11,'1.248.227.206','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(12,'1.255.226.157','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(13,'1.31.168.171','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(14,'1.31.168.4','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(15,'1.31.169.106','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(16,'1.31.169.151','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(17,'1.31.169.167','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(18,'1.31.169.196','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(19,'1.31.169.219','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(20,'1.31.169.52','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(21,'1.31.169.69','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(22,'1.31.169.85','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(23,'1.31.169.89','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(24,'1.55.33.86','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(25,'1.62.252.20','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(26,'1.94.123.200','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(27,'1.94.210.229','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(28,'1.95.54.27','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(29,'101.100.150.97','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(30,'101.126.128.106','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(31,'101.126.129.179','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(32,'101.126.130.242','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(33,'101.126.14.37','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(34,'101.126.142.219','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(35,'101.126.144.104','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(36,'101.126.146.27','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(37,'101.126.157.138','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(38,'101.126.16.21','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(39,'101.126.24.58','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(40,'101.126.24.71','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(41,'101.126.26.93','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(42,'101.126.31.191','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(43,'101.126.4.240','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(44,'101.126.43.232','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(45,'101.126.54.23','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(46,'101.126.54.66','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(47,'101.126.54.88','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(48,'101.126.55.179','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(49,'101.126.55.63','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(50,'101.126.55.66','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(51,'101.126.55.95','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(52,'101.126.6.19','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(53,'101.126.68.11','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(54,'101.126.69.201','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(55,'101.126.71.100','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(56,'101.126.82.218','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(57,'101.126.84.11','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(58,'101.126.88.203','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(59,'101.126.88.93','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(60,'101.126.89.144','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(61,'101.126.89.164','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(62,'101.126.89.35','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(63,'101.126.91.34','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(64,'101.126.95.119','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(65,'101.133.235.172','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(66,'101.200.243.197','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(67,'101.201.38.226','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(68,'101.227.203.162','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(69,'101.227.53.189','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(70,'101.227.79.215','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(71,'101.245.82.77','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(72,'101.32.161.29','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(73,'101.35.52.147','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(74,'101.36.107.103','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(75,'101.36.107.228','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(76,'101.36.108.134','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(77,'101.36.108.158','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(78,'101.36.111.119','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(79,'101.36.113.241','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(80,'101.36.120.76','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(81,'101.36.122.23','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(82,'101.36.123.102','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(83,'101.36.123.173','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(84,'101.36.124.127','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(85,'101.36.126.138','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(86,'101.36.65.131','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(87,'101.43.142.81','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(88,'101.43.172.119','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(89,'101.43.78.118','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(90,'101.44.35.141','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(91,'101.47.135.95','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(92,'101.47.140.106','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(93,'101.47.140.123','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(94,'101.47.140.127','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(95,'101.47.140.130','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(96,'101.47.140.137','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(97,'101.47.140.146','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(98,'101.47.140.158','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(99,'101.47.140.162','malicious',NULL,NULL,NULL,0,NULL,'2025-12-07 07:15:29'),(100,'101.47.140.190','malicious',NULL,75,NULL,0,NULL,'2025-12-07 07:15:29'),(352,'101.126.67.255','malicious',NULL,75,NULL,0,NULL,'2025-12-07 08:25:03'),(400,'101.47.140.212','malicious',NULL,75,NULL,0,NULL,'2025-12-07 08:25:03'),(553,'101.126.67.70','malicious',NULL,75,NULL,0,NULL,'2025-12-07 09:12:35'),(574,'101.36.104.242','malicious',NULL,75,NULL,0,NULL,'2025-12-07 09:12:35'),(579,'101.36.109.130','malicious',NULL,75,NULL,0,NULL,'2025-12-07 09:12:35'),(606,'1.220.64.218','malicious',NULL,75,NULL,0,NULL,'2025-12-07 14:17:47'),(627,'101.100.194.199','malicious',NULL,75,NULL,0,NULL,'2025-12-07 14:17:47'),(634,'101.126.153.85','malicious',NULL,75,NULL,0,NULL,'2025-12-07 14:17:47'),(640,'101.126.27.208','malicious',NULL,75,NULL,0,NULL,'2025-12-07 14:17:47'),(656,'101.126.81.18','malicious',NULL,75,NULL,0,NULL,'2025-12-07 14:17:47'),(677,'101.36.107.233','malicious',NULL,75,NULL,0,NULL,'2025-12-07 14:17:47'),(680,'101.36.109.176','malicious',NULL,75,NULL,0,NULL,'2025-12-07 14:17:47'),(683,'101.36.119.50','malicious',NULL,75,NULL,0,NULL,'2025-12-07 14:17:47'),(690,'101.36.98.91','malicious',NULL,75,NULL,0,NULL,'2025-12-07 14:17:47'),(694,'101.47.140.105','malicious',NULL,75,NULL,0,NULL,'2025-12-07 14:17:47'),(801,'1.1.179.25','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(802,'1.13.79.144','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(803,'1.145.84.143','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(804,'1.171.19.69','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(806,'1.214.29.155','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(813,'1.85.204.96','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(814,'1.95.186.78','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(817,'101.126.129.9','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(818,'101.126.13.34','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(819,'101.126.131.101','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(820,'101.126.135.154','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(821,'101.126.138.155','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(823,'101.126.143.71','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(826,'101.126.155.86','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(828,'101.126.24.74','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(830,'101.126.27.196','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(832,'101.126.32.21','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(833,'101.126.35.9','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(834,'101.126.4.215','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(835,'101.126.42.111','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(836,'101.126.54.167','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(840,'101.126.54.95','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(844,'101.126.55.67','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(848,'101.126.70.177','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(850,'101.126.81.188','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(851,'101.126.81.213','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(852,'101.126.83.54','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(853,'101.126.85.58','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(854,'101.126.88.251','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(856,'101.126.89.0','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(859,'101.126.90.24','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(860,'101.126.91.58','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(862,'101.168.10.173','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(863,'101.201.105.142','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(865,'101.226.19.192','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(869,'101.251.219.202','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(870,'101.32.128.104','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(871,'101.33.78.6','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(875,'101.36.107.46','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(879,'101.36.116.29','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(880,'101.36.119.218','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(886,'101.36.125.183','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(887,'101.36.228.201','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(890,'101.43.120.76','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(892,'101.43.48.241','malicious',NULL,75,NULL,0,NULL,'2025-12-17 00:37:52'),(893,'101.44.3.213','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 00:37:52'),(958,'101.13.5.26','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 02:04:40'),(1043,'101.126.66.30','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 11:09:26'),(1099,'101.47.140.164','malicious',NULL,NULL,NULL,0,NULL,'2025-12-17 11:09:26'),(1100,'1.12.64.80','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1101,'1.14.95.153','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1102,'1.171.34.59','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1103,'1.197.102.62','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1110,'1.54.166.99','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1113,'1.71.249.167','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1114,'1.85.205.126','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1115,'1.94.67.207','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1117,'101.109.51.175','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1118,'101.126.11.137','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1121,'101.126.13.40','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1124,'101.126.141.163','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1126,'101.126.144.222','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1130,'101.126.158.126','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1134,'101.126.3.247','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1136,'101.126.54.36','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1141,'101.126.77.228','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1144,'101.126.83.152','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1145,'101.126.83.211','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1153,'101.168.57.163','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1168,'101.36.122.139','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1169,'101.36.122.183','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1174,'101.36.224.146','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1176,'101.39.241.221','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1177,'101.42.18.102','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1186,'101.47.140.216','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1187,'101.47.140.222','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1188,'101.47.140.226','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1189,'101.47.140.243','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1190,'101.47.140.25','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1191,'101.47.140.255','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1192,'101.47.140.73','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1193,'101.47.140.82','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1194,'101.47.141.103','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1195,'101.47.141.104','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1196,'101.47.141.119','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1197,'101.47.141.12','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1198,'101.47.141.125','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1199,'101.47.141.128','malicious',NULL,75,NULL,0,NULL,'2025-12-19 13:29:57'),(1362,'101.36.108.248','malicious',NULL,75,NULL,0,NULL,'2025-12-19 16:32:47'),(1367,'101.36.117.148','malicious',NULL,75,NULL,0,NULL,'2025-12-19 16:32:47'),(1394,'101.47.140.230','malicious',NULL,75,NULL,0,NULL,'2025-12-19 16:32:47'),(1397,'101.47.140.254','malicious',NULL,75,NULL,0,NULL,'2025-12-19 16:32:47'),(1400,'8.8.8.8','clean','US',0,NULL,0,NULL,'2025-12-20 01:23:54'),(1401,'8.8.4.4','clean','US',0,NULL,0,NULL,'2025-12-20 01:23:54'),(1402,'1.1.1.1','clean','US',0,NULL,0,NULL,'2025-12-20 01:23:54'),(1403,'1.0.0.1','clean','US',0,NULL,0,NULL,'2025-12-20 01:23:54'),(1404,'208.67.222.222','clean','US',0,NULL,0,NULL,'2025-12-20 01:23:54'),(1405,'208.67.220.220','clean','US',0,NULL,0,NULL,'2025-12-20 01:23:54'),(1406,'9.9.9.9','clean','US',0,NULL,0,NULL,'2025-12-20 01:23:54'),(1407,'149.112.112.112','clean','CA',0,NULL,0,NULL,'2025-12-20 01:23:54'),(1408,'76.76.2.0','clean','US',0,NULL,0,NULL,'2025-12-20 01:23:54'),(1409,'94.140.14.14','clean','CY',0,NULL,0,NULL,'2025-12-20 01:23:54'),(1412,'1.15.114.102','malicious',NULL,75,NULL,0,NULL,'2025-12-20 08:20:58'),(1417,'1.221.66.66','malicious',NULL,75,NULL,0,NULL,'2025-12-20 08:20:58'),(1422,'1.34.138.79','malicious',NULL,75,NULL,0,NULL,'2025-12-20 08:20:58'),(1423,'1.36.205.147','malicious',NULL,75,NULL,0,NULL,'2025-12-20 08:20:58'),(1434,'101.126.143.51','malicious',NULL,75,NULL,0,NULL,'2025-12-20 08:20:58'),(1474,'101.168.15.57','malicious',NULL,75,NULL,0,NULL,'2025-12-20 08:20:58'),(1511,'1.171.34.122','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1513,'1.20.233.186','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1514,'1.213.196.20','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1516,'1.220.119.116','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1526,'1.94.183.227','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1527,'1.95.2.47','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1531,'101.126.130.65','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1545,'101.126.54.245','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1553,'101.126.66.223','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1559,'101.126.81.162','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1577,'101.132.193.238','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1578,'101.168.56.97','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1579,'101.176.36.231','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1580,'101.200.222.1','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29'),(1593,'101.36.119.69','malicious',NULL,75,NULL,0,NULL,'2025-12-23 14:33:29');
/*!40000 ALTER TABLE `simulation_ip_pool` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `simulation_runs`
--

DROP TABLE IF EXISTS `simulation_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `simulation_runs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `run_uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_id` int DEFAULT NULL,
  `run_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `attack_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` json DEFAULT NULL,
  `target_agent_id` int DEFAULT NULL,
  `events_generated` int DEFAULT '0',
  `events_blocked` int DEFAULT '0',
  `detection_rate` decimal(5,4) DEFAULT NULL,
  `false_positive_rate` decimal(5,4) DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `duration_seconds` int DEFAULT NULL,
  `results` json DEFAULT NULL,
  `triggered_by_user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `run_uuid` (`run_uuid`),
  KEY `idx_uuid` (`run_uuid`),
  KEY `idx_status` (`status`),
  KEY `template_id` (`template_id`),
  KEY `target_agent_id` (`target_agent_id`),
  KEY `triggered_by_user_id` (`triggered_by_user_id`),
  CONSTRAINT `simulation_runs_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `simulation_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `simulation_runs_ibfk_2` FOREIGN KEY (`target_agent_id`) REFERENCES `agents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `simulation_runs_ibfk_3` FOREIGN KEY (`triggered_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `simulation_runs`
--

LOCK TABLES `simulation_runs` WRITE;
/*!40000 ALTER TABLE `simulation_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `simulation_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `simulation_targets`
--

DROP TABLE IF EXISTS `simulation_targets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `simulation_targets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` int DEFAULT '5001',
  `api_key` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agent_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `last_tested_at` timestamp NULL DEFAULT NULL,
  `test_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_name` (`name`),
  UNIQUE KEY `unique_ip_port` (`ip_address`,`port`),
  KEY `agent_id` (`agent_id`),
  CONSTRAINT `simulation_targets_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `simulation_targets`
--

LOCK TABLES `simulation_targets` WRITE;
/*!40000 ALTER TABLE `simulation_targets` DISABLE KEYS */;
/*!40000 ALTER TABLE `simulation_targets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `simulation_templates`
--

DROP TABLE IF EXISTS `simulation_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `simulation_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `template_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `attack_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parameters` json NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_by_user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `simulation_templates_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `simulation_templates`
--

LOCK TABLES `simulation_templates` WRITE;
/*!40000 ALTER TABLE `simulation_templates` DISABLE KEYS */;
INSERT INTO `simulation_templates` VALUES (1,'basic_brute_force','Simple brute force attack from single IP','brute_force','{\"unique_ips\": 1, \"total_events\": 100, \"failed_attempts\": 95, \"time_distribution\": \"constant\"}',1,NULL,'2025-12-04 17:23:03','2025-12-04 17:23:03'),(2,'distributed_brute_force','Brute force attack from multiple IPs','brute_force','{\"unique_ips\": 50, \"total_events\": 500, \"failed_attempts\": 450, \"time_distribution\": \"random\"}',1,NULL,'2025-12-04 17:23:03','2025-12-04 17:23:03'),(3,'credential_stuffing','Automated login attempts with leaked credentials','credential_stuffing','{\"unique_ips\": 100, \"total_events\": 1000, \"failed_attempts\": 900, \"username_list_size\": 50}',1,NULL,'2025-12-04 17:23:03','2025-12-04 17:23:03'),(4,'slow_attack','Low-volume attack over extended period','slow_attack','{\"unique_ips\": 10, \"total_events\": 200, \"failed_attempts\": 180, \"attack_duration_hours\": 24}',1,NULL,'2025-12-04 17:23:03','2025-12-04 17:23:03');
/*!40000 ALTER TABLE `simulation_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci,
  `value_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'string',
  `category` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'general',
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_sensitive` tinyint(1) DEFAULT '0',
  `is_public` tinyint(1) DEFAULT '0',
  `updated_by_user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_category` (`category`),
  KEY `updated_by_user_id` (`updated_by_user_id`),
  CONSTRAINT `system_settings_ibfk_1` FOREIGN KEY (`updated_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'system_name','SSH Guardian v3.0','string','general','System display name',0,0,NULL,'2025-12-04 23:58:02','2025-12-23 15:15:31'),(2,'max_login_attempts','5','number','security','Maximum failed login attempts before blocking',0,0,NULL,'2025-12-04 23:58:02','2025-12-04 23:58:02'),(3,'block_duration_minutes','60','number','security','Default block duration in minutes',0,0,NULL,'2025-12-04 23:58:02','2025-12-04 23:58:02'),(4,'enable_auto_blocking','true','boolean','security','Automatically block suspicious IPs',0,0,NULL,'2025-12-04 23:58:02','2025-12-04 23:58:02'),(5,'risk_score_threshold','70','number','security','Risk score threshold for auto-blocking',0,0,NULL,'2025-12-04 23:58:02','2025-12-04 23:58:02'),(6,'enable_notifications','true','boolean','notifications','Enable email/webhook notifications',0,0,NULL,'2025-12-04 23:58:02','2025-12-04 23:58:02'),(7,'notification_email','sohell.ranaa@gmail.com','string','notifications','Email address for notifications',0,0,NULL,'2025-12-04 23:58:02','2025-12-05 23:20:09'),(8,'data_retention_days','90','number','general','Number of days to retain event data',0,0,NULL,'2025-12-04 23:58:02','2025-12-04 23:58:02'),(9,'enable_geolocation','true','boolean','general','Enable IP geolocation lookup',0,0,NULL,'2025-12-04 23:58:02','2025-12-04 23:58:02'),(10,'dashboard_refresh_interval','30','number','general','Dashboard auto-refresh interval in seconds',0,0,NULL,'2025-12-04 23:58:02','2025-12-04 23:58:02'),(11,'time_format','12h','string','display','Time format (12h or 24h)',0,0,NULL,'2025-12-06 01:21:10','2025-12-17 10:16:59'),(12,'date_format','DD/MM/YYYY','string','display','Date format (YYYY-MM-DD, DD/MM/YYYY, MM/DD/YYYY)',0,0,NULL,'2025-12-06 01:21:10','2025-12-17 10:17:00'),(13,'timezone','Local','string','display','Display timezone',0,0,NULL,'2025-12-06 01:21:10','2025-12-20 08:53:45'),(14,'datetime_format','YYYY-MM-DD HH:mm:ss','string','display','Full datetime format',0,0,NULL,'2025-12-06 01:21:10','2025-12-06 01:21:10'),(15,'default_landing_page','overview','string','navigation','Default page shown after login',0,0,NULL,'2025-12-06 18:50:08','2025-12-17 08:40:35'),(17,'max_session_duration_days','30','number','system','Maximum session duration',0,0,NULL,'2025-12-18 15:18:06','2025-12-04 17:23:03'),(18,'otp_validity_minutes','5','number','system','OTP validity period',0,0,NULL,'2025-12-18 15:18:06','2025-12-04 17:23:03'),(19,'max_failed_attempts','5','number','system','Max failed login attempts before lockout',0,0,NULL,'2025-12-18 15:18:06','2025-12-04 17:23:03'),(20,'lockout_duration_minutes','30','number','system','Account lockout duration',0,0,NULL,'2025-12-18 15:18:06','2025-12-04 17:23:03'),(21,'default_block_duration_minutes','1440','number','system','Default IP block duration (24 hours)',0,0,NULL,'2025-12-18 15:18:06','2025-12-04 17:23:03'),(22,'enable_ml_processing','true','boolean','system','Enable ML risk analysis',0,0,NULL,'2025-12-18 15:18:06','2025-12-04 17:23:03'),(23,'enable_geoip_lookup','true','boolean','system','Enable GeoIP lookups',0,0,NULL,'2025-12-18 15:18:06','2025-12-04 17:23:03'),(24,'enable_threat_intel','true','boolean','system','Enable 3rd party threat intel APIs',0,0,NULL,'2025-12-18 15:18:06','2025-12-04 17:23:03'),(26,'enable_telegram_notifications','true','boolean','system','Enable Telegram notifications',0,0,NULL,'2025-12-18 15:18:06','2025-12-20 11:31:28'),(28,'simulation_retention_days','7','number','system','Number of days to keep simulation data',0,0,NULL,'2025-12-18 15:18:06','2025-12-04 17:23:03'),(29,'cache.events_list','{\"ttl_seconds\": 15, \"enabled\": 1, \"priority\": \"high\"}','json','cache','Live authentication events with pagination',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(30,'cache.events_count','{\"ttl_seconds\": 30, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Total event count for pagination',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(31,'cache.events_analysis','{\"ttl_seconds\": 30, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Event statistics and patterns',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(32,'cache.events_timeline','{\"ttl_seconds\": 30, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Time-based event distribution',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(33,'cache.ip_stats_list','{\"ttl_seconds\": 60, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','IP address statistics listing',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(34,'cache.ip_stats_summary','{\"ttl_seconds\": 60, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Aggregate IP statistics',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(35,'cache.ip_stats_detail','{\"ttl_seconds\": 120, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Individual IP details',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(36,'cache.blocking_list','{\"ttl_seconds\": 60, \"enabled\": 1, \"priority\": \"high\"}','json','cache','Active IP blocks',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(37,'cache.blocking_stats','{\"ttl_seconds\": 60, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Blocking statistics',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(38,'cache.blocking_rules','{\"ttl_seconds\": 300, \"enabled\": 1, \"priority\": \"low\"}','json','cache','Blocking rules configuration',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(39,'cache.geoip_lookup','{\"ttl_seconds\": 600, \"enabled\": 1, \"priority\": \"low\"}','json','cache','IP to location mapping',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(40,'cache.geoip_stats','{\"ttl_seconds\": 600, \"enabled\": 1, \"priority\": \"low\"}','json','cache','Geographic distribution stats',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 23:52:40'),(41,'cache.geoip_recent','{\"ttl_seconds\": 300, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Recently looked up locations',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(42,'cache.threat_intel_lookup','{\"ttl_seconds\": 600, \"enabled\": 1, \"priority\": \"low\"}','json','cache','IP threat intelligence data',0,0,NULL,'2025-12-05 18:59:08','2025-12-18 06:28:56'),(43,'cache.threat_intel_stats','{\"ttl_seconds\": 600, \"enabled\": 1, \"priority\": \"low\"}','json','cache','Threat intelligence statistics',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 23:38:15'),(44,'cache.threat_intel_recent','{\"ttl_seconds\": 300, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Recently analyzed threats',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(45,'cache.ml_predictions','{\"ttl_seconds\": 180, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Machine learning predictions',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(46,'cache.ml_models','{\"ttl_seconds\": 300, \"enabled\": 1, \"priority\": \"low\"}','json','cache','Model information and status',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(47,'cache.ml_overview','{\"ttl_seconds\": 180, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','ML dashboard overview',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(48,'cache.audit_list','{\"ttl_seconds\": 120, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Audit log entries',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(49,'cache.audit_stats','{\"ttl_seconds\": 120, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Audit log statistics',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(50,'cache.audit_actions','{\"ttl_seconds\": 300, \"enabled\": 1, \"priority\": \"low\"}','json','cache','Available audit action types',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(51,'cache.notifications_list','{\"ttl_seconds\": 60, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Notification history',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(52,'cache.notifications_stats','{\"ttl_seconds\": 60, \"enabled\": 1, \"priority\": \"normal\"}','json','cache','Notification statistics',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(53,'cache.trends_overview','{\"ttl_seconds\": 300, \"enabled\": 1, \"priority\": \"low\"}','json','cache','Trend analysis overview',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(54,'cache.trends_daily','{\"ttl_seconds\": 300, \"enabled\": 1, \"priority\": \"low\"}','json','cache','Daily activity trends',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(55,'cache.trends_geographic','{\"ttl_seconds\": 300, \"enabled\": 1, \"priority\": \"low\"}','json','cache','Geographic distribution trends',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(56,'cache.daily_reports','{\"ttl_seconds\": 900, \"enabled\": 1, \"priority\": \"low\"}','json','cache','Generated daily reports',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(57,'cache.dashboard_summary','{\"ttl_seconds\": 30, \"enabled\": 1, \"priority\": \"critical\"}','json','cache','Main dashboard statistics',0,0,NULL,'2025-12-05 18:59:08','2025-12-17 08:57:34'),(58,'email_routing_rules','[{\"id\": \"986ab0c2\", \"name\": \"Test Routing\", \"description\": \"\", \"agents\": [\"all\"], \"rule_types\": [\"all\"], \"email_addresses\": [\"sohell.ranaa@gmail.com\"], \"is_enabled\": true, \"priority\": 50, \"created_at\": \"2025-12-19T18:32:44.268625\"}]','json','notifications','Email routing rules: maps agents and rule types to recipient email addresses',0,0,NULL,'2025-12-19 18:32:35','2025-12-19 18:32:44');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thesis_figures`
--

DROP TABLE IF EXISTS `thesis_figures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `thesis_figures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `figure_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caption` text COLLATE utf8mb4_unicode_ci,
  `image_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `figure_id` (`figure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thesis_figures`
--

LOCK TABLES `thesis_figures` WRITE;
/*!40000 ALTER TABLE `thesis_figures` DISABLE KEYS */;
/*!40000 ALTER TABLE `thesis_figures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thesis_metadata`
--

DROP TABLE IF EXISTS `thesis_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `thesis_metadata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `meta_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value` text COLLATE utf8mb4_unicode_ci,
  `meta_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thesis_metadata`
--

LOCK TABLES `thesis_metadata` WRITE;
/*!40000 ALTER TABLE `thesis_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `thesis_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thesis_references`
--

DROP TABLE IF EXISTS `thesis_references`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `thesis_references` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ref_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authors` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year` int DEFAULT NULL,
  `volume` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issue` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pages` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accessed_date` date DEFAULT NULL,
  `ref_type` enum('journal','conference','book','website','report','thesis','other') COLLATE utf8mb4_unicode_ci DEFAULT 'other',
  `display_order` int DEFAULT '0',
  `formatted_citation` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ref_key` (`ref_key`),
  KEY `idx_year` (`year`),
  KEY `idx_type` (`ref_type`),
  KEY `idx_order` (`display_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thesis_references`
--

LOCK TABLES `thesis_references` WRITE;
/*!40000 ALTER TABLE `thesis_references` DISABLE KEYS */;
/*!40000 ALTER TABLE `thesis_references` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thesis_sections`
--

DROP TABLE IF EXISTS `thesis_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `thesis_sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `section_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chapter_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_html` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_order` int DEFAULT '0',
  `toc_level` int DEFAULT '1',
  `show_in_toc` tinyint(1) DEFAULT '1',
  `is_active` tinyint(1) DEFAULT '1',
  `word_count` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_key` (`section_key`),
  KEY `idx_parent` (`parent_key`),
  KEY `idx_chapter` (`chapter_number`),
  KEY `idx_order` (`display_order`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thesis_sections`
--

LOCK TABLES `thesis_sections` WRITE;
/*!40000 ALTER TABLE `thesis_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `thesis_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thesis_tables`
--

DROP TABLE IF EXISTS `thesis_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `thesis_tables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `table_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caption` text COLLATE utf8mb4_unicode_ci,
  `table_html` mediumtext COLLATE utf8mb4_unicode_ci,
  `display_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `table_id` (`table_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thesis_tables`
--

LOCK TABLES `thesis_tables` WRITE;
/*!40000 ALTER TABLE `thesis_tables` DISABLE KEYS */;
/*!40000 ALTER TABLE `thesis_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trusted_sources`
--

DROP TABLE IF EXISTS `trusted_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trusted_sources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `source_type` enum('ip','network','user_ip') COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `network_cidr` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trust_score` decimal(5,2) DEFAULT '0.00',
  `successful_logins` int DEFAULT '0',
  `failed_logins` int DEFAULT '0',
  `unique_users` int DEFAULT '1',
  `first_seen_at` timestamp NULL DEFAULT NULL,
  `last_seen_at` timestamp NULL DEFAULT NULL,
  `days_active` int DEFAULT '0',
  `is_auto_trusted` tinyint(1) DEFAULT '0',
  `is_manually_trusted` tinyint(1) DEFAULT '0',
  `trusted_at` timestamp NULL DEFAULT NULL,
  `trust_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_ip` (`ip_address`),
  UNIQUE KEY `unique_network` (`network_cidr`),
  KEY `idx_trust_score` (`trust_score`),
  KEY `idx_auto_trusted` (`is_auto_trusted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trusted_sources`
--

LOCK TABLES `trusted_sources` WRITE;
/*!40000 ALTER TABLE `trusted_sources` DISABLE KEYS */;
/*!40000 ALTER TABLE `trusted_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ufw_audit_log`
--

DROP TABLE IF EXISTS `ufw_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ufw_audit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_id` int NOT NULL,
  `command_id` int DEFAULT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rule_before` text COLLATE utf8mb4_unicode_ci,
  `rule_after` text COLLATE utf8mb4_unicode_ci,
  `performed_by_user_id` int DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `success` tinyint(1) DEFAULT '1',
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_agent` (`agent_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created` (`created_at`),
  KEY `performed_by_user_id` (`performed_by_user_id`),
  CONSTRAINT `ufw_audit_log_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ufw_audit_log_ibfk_2` FOREIGN KEY (`performed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ufw_audit_log`
--

LOCK TABLES `ufw_audit_log` WRITE;
/*!40000 ALTER TABLE `ufw_audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ufw_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ufw_rule_templates`
--

DROP TABLE IF EXISTS `ufw_rule_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ufw_rule_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `template_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `category` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'in',
  `protocol` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_common` tinyint(1) DEFAULT '0',
  `display_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_common` (`is_common`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ufw_rule_templates`
--

LOCK TABLES `ufw_rule_templates` WRITE;
/*!40000 ALTER TABLE `ufw_rule_templates` DISABLE KEYS */;
INSERT INTO `ufw_rule_templates` VALUES (1,'Allow SSH','Allow incoming SSH connections on port 22','security','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(2,'Allow HTTP','Allow incoming HTTP connections on port 80','web','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(3,'Allow HTTPS','Allow incoming HTTPS connections on port 443','web','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(4,'Allow HTTP and HTTPS','Allow both HTTP and HTTPS','web','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(5,'Allow Custom Port','Allow a specific port','general','allow','in','tcp|udp','number',NULL,NULL,1,0,'2025-12-06 15:17:15'),(6,'Block IP','Block all traffic from a specific IP address','security','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(7,'Allow IP','Allow all traffic from a specific IP address','security','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(8,'Allow Port from IP','Allow a port from a specific IP only','security','allow','in',NULL,'Port number',NULL,NULL,1,0,'2025-12-06 15:17:15'),(9,'Allow SSH from IP','Allow SSH only from a specific IP','security','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(10,'Limit SSH','Rate limit SSH connections (brute force protection)','security','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(11,'Allow MySQL','Allow MySQL connections on port 3306','database','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(12,'Allow PostgreSQL','Allow PostgreSQL connections on port 5432','database','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(13,'Allow Redis','Allow Redis connections on port 6379','database','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(14,'Allow MongoDB','Allow MongoDB connections on port 27017','database','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(15,'Allow SMTP','Allow SMTP on port 25','mail','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(16,'Allow IMAP','Allow IMAP on port 143','mail','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(17,'Allow IMAPS','Allow IMAPS on port 993','mail','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(18,'Allow FTP','Allow FTP on ports 20,21','file','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(19,'Allow DNS','Allow DNS on port 53','network','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(20,'Allow OpenVPN','Allow OpenVPN on port 1194','vpn','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(21,'Allow WireGuard','Allow WireGuard on port 51820','vpn','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(22,'SSH Guardian Dashboard','Allow SSH Guardian Dashboard on port 8081','system','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(23,'Allow Subnet','Allow all traffic from a subnet','network','allow','in',NULL,NULL,NULL,NULL,1,0,'2025-12-06 15:17:15'),(24,'Deny Port','Deny incoming connections on a port','general','allow','in','tcp|udp','number',NULL,NULL,1,0,'2025-12-06 15:17:15');
/*!40000 ALTER TABLE `ufw_rule_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_behavioral_profiles`
--

DROP TABLE IF EXISTS `user_behavioral_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_behavioral_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `typical_hours` json DEFAULT NULL COMMENT 'Hour distribution: {"0": count, "1": count, ..., "23": count}',
  `typical_days` json DEFAULT NULL COMMENT 'Day distribution: {"Mon": count, "Tue": count, ...}',
  `known_ips` json DEFAULT NULL COMMENT 'Known IPs: {"ip": count, ...}',
  `known_countries` json DEFAULT NULL COMMENT 'Known countries: {"US": count, "UK": count, ...}',
  `known_cities` json DEFAULT NULL COMMENT 'Known cities: {"New York": count, ...}',
  `login_count` int DEFAULT '0',
  `successful_count` int DEFAULT '0',
  `failed_count` int DEFAULT '0',
  `avg_session_gap_hours` float DEFAULT NULL COMMENT 'Average hours between logins',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_trained_at` timestamp NULL DEFAULT NULL,
  `model_version` int DEFAULT '1',
  `confidence_score` float DEFAULT '0' COMMENT 'Confidence in learned patterns (0-1)',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_username` (`username`),
  KEY `idx_last_login` (`last_login_at`),
  KEY `idx_login_count` (`login_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_behavioral_profiles`
--

LOCK TABLES `user_behavioral_profiles` WRITE;
/*!40000 ALTER TABLE `user_behavioral_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_behavioral_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_login_baselines`
--

DROP TABLE IF EXISTS `user_login_baselines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_login_baselines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_latitude` decimal(10,8) DEFAULT NULL,
  `last_longitude` decimal(11,8) DEFAULT NULL,
  `last_country_code` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_ip_text` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `login_count` int DEFAULT '0',
  `successful_logins` int DEFAULT '0',
  `failed_logins` int DEFAULT '0',
  `known_locations` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`),
  KEY `idx_last_login` (`last_login_at`),
  KEY `idx_country` (`last_country_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_login_baselines`
--

LOCK TABLES `user_login_baselines` WRITE;
/*!40000 ALTER TABLE `user_login_baselines` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_login_baselines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_otps`
--

DROP TABLE IF EXISTS `user_otps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_otps` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `otp_code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_used` tinyint(1) DEFAULT '0',
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_expires` (`expires_at`),
  CONSTRAINT `user_otps_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_otps`
--

LOCK TABLES `user_otps` WRITE;
/*!40000 ALTER TABLE `user_otps` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_otps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sessions`
--

DROP TABLE IF EXISTS `user_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `session_token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `expires_at` timestamp NOT NULL,
  `last_activity_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `idx_user` (`user_id`),
  KEY `idx_token` (`session_token`),
  KEY `idx_expires` (`expires_at`),
  CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sessions`
--

LOCK TABLES `user_sessions` WRITE;
/*!40000 ALTER TABLE `user_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_login_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failed_login_attempts` int DEFAULT '0',
  `locked_until` timestamp NULL DEFAULT NULL,
  `preferences` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_role` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@sshguardian.local','$2b$12$t5dDrNRWHr9W1PFOMLvBAOeeC68X8x2KD34MRnSNOr8PtyhHdPYtm','Admin@123',1,1,'2025-12-04 17:35:50','2025-12-20 15:39:51','127.0.0.1',0,NULL,NULL,'2025-12-04 17:35:50','2025-12-23 22:56:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-24  6:57:22
